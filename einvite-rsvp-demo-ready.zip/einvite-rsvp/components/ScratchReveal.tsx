'use client';

import { useEffect, useRef, useState } from 'react';

export default function ScratchReveal() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [isDown, setIsDown] = useState(false);
  const [revealed, setRevealed] = useState(false);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const dpr = Math.max(1, window.devicePixelRatio || 1);
    const rect = canvas.getBoundingClientRect();
    canvas.width = Math.floor(rect.width * dpr);
    canvas.height = Math.floor(rect.height * dpr);
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.scale(dpr, dpr);

    const gradient = ctx.createLinearGradient(0, 0, rect.width, rect.height);
    gradient.addColorStop(0, '#c99f4b');
    gradient.addColorStop(0.45, '#f0d38a');
    gradient.addColorStop(1, '#b88a37');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, rect.width, rect.height);

    ctx.globalAlpha = 0.28;
    ctx.strokeStyle = '#7d5a1d';
    ctx.lineWidth = 1;
    for (let x = -rect.height; x < rect.width; x += 12) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x + rect.height, rect.height);
      ctx.stroke();
    }
    ctx.globalAlpha = 1;
    ctx.fillStyle = '#66491d';
    ctx.font = '600 12px Arial';
    ctx.textAlign = 'center';
    ctx.letterSpacing = '2px';
    ctx.fillText('SCRATCH TO REVEAL', rect.width / 2, rect.height / 2 + 4);
  }, []);

  const scratch = (clientX: number, clientY: number) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const dpr = Math.max(1, window.devicePixelRatio || 1);
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const x = (clientX - rect.left) * dpr;
    const y = (clientY - rect.top) * dpr;
    ctx.save();
    ctx.globalCompositeOperation = 'destination-out';
    ctx.beginPath();
    ctx.arc(x, y, 28 * dpr, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  };

  const revealAll = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    ctx?.clearRect(0, 0, canvas.width, canvas.height);
    setRevealed(true);
  };

  return (
    <div className="scratch-wrap" aria-label="Scratch card reveal">
      <div className="scratch-underlay">
        <span className="save-label">SAVE THE DATE</span>
        <strong>29 · 08 · 2026</strong>
        <small>Mahesh &amp; Sai Sree</small>
      </div>
      {!revealed && (
        <canvas
          ref={canvasRef}
          className="scratch-canvas"
          onPointerDown={(e) => { setIsDown(true); scratch(e.clientX, e.clientY); }}
          onPointerMove={(e) => { if (isDown) scratch(e.clientX, e.clientY); }}
          onPointerUp={() => setIsDown(false)}
          onPointerCancel={() => setIsDown(false)}
          onPointerLeave={() => setIsDown(false)}
        />
      )}
      <button className="reveal-link" type="button" onClick={revealAll}>Reveal instantly</button>
    </div>
  );
}
