'use client';

import { AnimatePresence, motion } from 'framer-motion';
import { FormEvent, useState } from 'react';
import ScratchReveal from './ScratchReveal';

const events = [
  { key: 'haldi', name: 'Haldi', date: 'Thursday · 27 August', time: '8:00 AM onwards', venue: 'Family Residence' },
  { key: 'pelli', name: 'Pellikuthuru & Pellikoduku', date: 'Thursday · 27 August', time: '6:00 PM onwards', venue: 'Family Residence' },
  { key: 'sangeeth', name: 'Sangeeth', date: 'Friday · 28 August', time: '6:30 PM onwards', venue: 'Celebration Hall' },
  { key: 'wedding', name: 'Wedding', date: 'Saturday · 29 August', time: 'Muhurtham · 10:42 AM', venue: 'Grand Convention Centre' },
];

function DecorativeTemple() {
  return (
    <div className="temple-art" aria-hidden="true">
      <div className="temple-sun" />
      <div className="temple-tower"><span/><span/><span/><span/></div>
      <div className="temple-base" />
      <div className="temple-floor" />
    </div>
  );
}

function EventArtwork({ type }: { type: string }) {
  return (
    <div className={`event-illustration ${type}`} aria-hidden="true">
      <div className="art-sun" />
      <div className="art-arch" />
      <div className="art-couple"><i/><i/></div>
      <div className="art-floor" />
      <span className="petal p1">✦</span><span className="petal p2">✦</span><span className="petal p3">✦</span>
    </div>
  );
}

export default function InviteExperience() {
  const [opened, setOpened] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const form = new FormData(e.currentTarget);
    const payload = Object.fromEntries(form.entries());
    localStorage.setItem('einvite-demo-rsvp', JSON.stringify({ ...payload, savedAt: new Date().toISOString() }));
    setSubmitted(true);
  };

  return (
    <main className="page-shell">
      <AnimatePresence mode="wait">
        {!opened ? (
          <motion.section
            key="cover"
            className="cover-screen"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0, scale: 1.025, filter: 'blur(3px)' }}
            transition={{ duration: 0.65 }}
          >
            <div className="top-ornament" aria-hidden="true"><span>❦</span><i/><span>❦</span></div>
            <p className="eyebrow">YOU ARE INVITED TO THE WEDDING OF</p>
            <h1>Mahesh <span>&amp;</span> Sai Sree</h1>
            <p className="cover-date">29 · AUGUST · 2026</p>
            <button className="primary-btn" onClick={() => setOpened(true)}>OPEN INVITATION</button>
            <DecorativeTemple />
            <p className="tap-note">Tap to enter our celebration</p>
          </motion.section>
        ) : (
          <motion.div
            key="invite"
            className="invite-body"
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.75 }}
          >
            <div className="petal-layer" aria-hidden="true">
              {Array.from({ length: 14 }).map((_, i) => <span key={i} style={{ '--i': i } as React.CSSProperties}>•</span>)}
            </div>

            <section className="hero-section section-pad">
              <div className="hero-floral">❦</div>
              <p className="eyebrow">WITH JOY IN OUR HEARTS</p>
              <h2>Mahesh <span>&amp;</span> Sai Sree</h2>
              <p className="subcopy">Together with our families, we invite you to celebrate the beginning of our forever.</p>
              <div className="date-lockup"><b>29</b><span>AUG</span><b>2026</b></div>
              <ScratchReveal />
              <div className="scroll-cue">SCROLL TO CELEBRATE <span>⌄</span></div>
            </section>

            <section className="section-pad schedule-section">
              <p className="eyebrow center">CELEBRATE WITH US</p>
              <h3>Wedding Festivities</h3>
              <p className="section-intro">Four beautiful moments, one unforgettable celebration.</p>
              <div className="event-stack">
                {events.map((event, idx) => (
                  <motion.article
                    className="event-card"
                    key={event.name}
                    initial={{ opacity: 0, y: 32 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true, amount: 0.18 }}
                    transition={{ duration: 0.55, delay: idx * 0.05 }}
                  >
                    <EventArtwork type={event.key} />
                    <div className="event-copy">
                      <p className="event-number">0{idx + 1}</p>
                      <h4>{event.name}</h4>
                      <p>{event.date}</p>
                      <p>{event.time}</p>
                      <p className="venue">⌖ {event.venue}</p>
                      <button className="secondary-btn" type="button">GET DIRECTIONS</button>
                    </div>
                  </motion.article>
                ))}
              </div>
            </section>

            <section className="section-pad gallery-section">
              <p className="eyebrow center">A FEW MOMENTS OF US</p>
              <h3>Our Story</h3>
              <div className="gallery-row">
                <div className="photo-card"><span>M</span><small>the beginning</small></div>
                <div className="photo-card featured"><span>♥</span><small>our favorite chapter</small></div>
                <div className="photo-card"><span>S</span><small>forever ahead</small></div>
              </div>
            </section>

            <section className="section-pad rsvp-section" id="rsvp">
              <div className="rsvp-ornament">❦</div>
              <p className="eyebrow center">KINDLY RESPOND</p>
              <h3>RSVP</h3>
              <p className="section-intro">Your presence would make our celebration complete.</p>
              {!submitted ? (
                <form className="rsvp-form" onSubmit={handleSubmit}>
                  <label><span>Your name</span><input name="name" placeholder="Enter your full name" required /></label>
                  <label><span>Attendance</span>
                    <select name="attendance" defaultValue="" required>
                      <option value="" disabled>Will you attend?</option>
                      <option value="accepts">Joyfully accepts</option>
                      <option value="declines">Regretfully declines</option>
                    </select>
                  </label>
                  <label><span>Guests</span><input name="guests" type="number" min="1" max="6" defaultValue="1" /></label>
                  <label><span>A note for the couple</span><textarea name="message" placeholder="Share your wishes..." rows={4} /></label>
                  <button className="primary-btn full" type="submit">SUBMIT RSVP</button>
                </form>
              ) : (
                <motion.div className="rsvp-success" initial={{ opacity: 0, scale: .96 }} animate={{ opacity: 1, scale: 1 }}>
                  <div>✓</div>
                  <h4>Thank you!</h4>
                  <p>Your RSVP has been saved for this demo.</p>
                </motion.div>
              )}
            </section>

            <section className="section-pad families-section">
              <p className="eyebrow center">WITH LOVE FROM</p>
              <h3>Our Families</h3>
              <p>We cannot wait to celebrate this beautiful beginning with you.</p>
              <div className="family-divider">❦</div>
              <strong>Mahesh &amp; Sai Sree</strong>
              <small>29 · 08 · 2026</small>
            </section>
          </motion.div>
        )}
      </AnimatePresence>
    </main>
  );
}
