# E-Invite RSVP — Demo Build

Demo-ready mobile wedding invitation based on the supplied Part 1 + Part 2 references.

## Demo flow
1. Opening invitation cover
2. Animated transition into invitation
3. Real pointer/touch scratch-to-reveal card
4. Event schedule with four event cards
5. Story/gallery section
6. RSVP form with demo submission confirmation
7. Family closing section

## Run locally
```bash
npm install
npm run dev
```
Open http://localhost:3000

## What is real in this demo
- Mobile-first UI
- Animations and transitions
- Touch/mouse scratch interaction
- RSVP form validation
- Demo RSVP persisted in browser localStorage
- WhatsApp/OpenGraph metadata and preview asset

## Production items after demo approval
- Replace placeholder names/details with final content
- Replace CSS illustrations with final approved artwork/photos
- Connect RSVP to Supabase
- Add Google Sheets sync
- Add actual map links
- Add guest-specific URLs and duplicate response handling
- Deploy to Vercel + custom domain and validate WhatsApp preview
