# Tomorrow's E-Invite Demo

## Fastest way to show it
Open `demo.html` directly in Chrome/Safari. It is a standalone demo and does not need npm, Supabase, or internet.

For a phone-like presentation on laptop, resize the browser narrow or use browser responsive/device mode.

## Demo sequence (60–90 seconds)
1. Start on the invitation cover and explain this is what opens after the WhatsApp link preview is tapped.
2. Tap **OPEN INVITATION** to show the animated transition into the full invitation.
3. Scratch the gold card with mouse/finger to reveal the wedding date.
4. Scroll through the four event cards and mention each can open Google Maps in production.
5. Show the gallery/story section.
6. Fill the RSVP quickly and submit it. The demo stores the response locally and shows confirmation.
7. Explain production data will go to **Supabase**, with a synchronized **Google Sheet** for easy management.

## What to say if asked what is complete
"The end-to-end guest experience is now demoable: opening invite, reveal interaction, event flow, gallery, RSVP submission and confirmation. The next phase is replacing demo content with final artwork/details and connecting RSVP to Supabase/Google Sheets before deployment."

## What not to promise tomorrow
- Do not say the current RSVP is already connected to Google Sheets.
- Do not say the sample event addresses or names are final.
- Do not describe the CSS illustrations as final artwork.

## Production next steps after approval
1. Lock final names, event data, photos and artwork.
2. Connect RSVP to Supabase.
3. Add Google Sheets synchronization.
4. Add real Google Maps links.
5. Configure guest-specific links / duplicate-response handling.
6. Deploy to Vercel and verify the WhatsApp preview on the production URL.
