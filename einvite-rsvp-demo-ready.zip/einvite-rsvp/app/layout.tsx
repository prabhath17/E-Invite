import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Mahesh & Sai Sree | Wedding Invitation',
  description: 'You are invited to celebrate the wedding of Mahesh & Sai Sree. Tap to open the invitation.',
  openGraph: {
    title: 'Mahesh & Sai Sree | Wedding Invitation',
    description: 'Tap to open our wedding invitation ✨',
    images: ['/assets/share-preview.png'],
    type: 'website',
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
